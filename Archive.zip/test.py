#test

import resume_parser

print(resume_parser.extract_email("My mail is karthik.vibuthi999@gmail.com"))