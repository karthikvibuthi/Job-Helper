import os
import spacy
from spacy.matcher import Matcher
import nltk
import resume_parser
import tika
from tika import parser


# Initialize Tika
tika.initVM()

# Ensure NLTK resources are available
nltk.download('wordnet')
nltk.download('omw-1.4')
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger')
nlp = spacy.load("en_core_web_sm")


# Function to fetch resume text from a PDF
def fetch_resume(pdf_file):
    parsed_pdf = parser.from_buffer(pdf_file)
    text = parsed_pdf['content']
    return text

def parse_resume(resume_text):
    # Load NLP model and matcher
    matcher = Matcher(nlp.vocab)

    # Initialize details dictionary with all keys from the updated Resume model
    details = {
        'name': '',
        'email': '',
        'skills': [],
        'degrees': [],
        'colleges': [],
        'education': '',
        'experience': [],
        'designations': [],
        'length': 0,
        'spellingMistakes': 0,
        'repeatedWords': {},
        'positiveBuzzwords': [],
        'negativeBuzzwords': [],
        'impactWords': {
            'action_words': [],
            'metrics': [],
            'weak_words': []
        },
        'bulletPoints': 0,
        'impactScore': 0,
        'certifications': [],
        'projects': [],
        'summary': '',
        'objective': '',
        'accomplishments': '',
        'score': 1
    }

    # Process resume text
    nlp_text = nlp(resume_text)
    noun_chunks = list(nlp_text.noun_chunks)

    # Extract details using various parser methods
    details['name'] = resume_parser.extract_name(nlp_text, matcher=matcher)
    details['email'] = resume_parser.extract_email(resume_text)
    details['skills'] = resume_parser.extract_skills(nlp_text, noun_chunks)
    details['education'] = resume_parser.get_education_section(nlp_text)
    #details['colleges'] = resume_parser.get_college_names(resume_text)
    #details['degrees'] = resume_parser.get_degree(resume_text)
    #details['designations'] = resume_parser.get_designations(resume_text)
    details['experience'] = resume_parser.get_experience_section(nlp_text)
    details['length'] = resume_parser.get_length(nlp_text)
    details['spellingMistakes'] = resume_parser.count_spelling_mistakes(nlp_text)
    details['repeatedWords'] = resume_parser.count_word_repetition(nlp_text)
    details['positiveBuzzwords'] = resume_parser.positive_buzzwords(resume_text)
    details['negativeBuzzwords'] = resume_parser.negative_buzzwords(resume_text)
    details['bulletPoints'] = resume_parser.count_bullet_points(resume_text)

    # Extract impact words and calculate impact score
    impact_words = resume_parser.extract_impact_words(resume_text)
    details['impactWords']['action_words'] = impact_words.get('action_words', [])
    details['impactWords']['metrics'] = impact_words.get('metrics', [])
    details['impactWords']['weak_words'] = impact_words.get('weak_words', [])
    details['impactScore'] = resume_parser.calculate_impact_score(details['impactWords'])

    # Placeholder for extracting certifications, projects, summary, objective, and accomplishments
    # Implement these in resume_parser if not done yet
    #details['certifications'] = resume_parser.extract_certifications(resume_text)  # List of certifications
    #details['projects'] = resume_parser.extract_projects(resume_text)              # List of projects
    #details['summary'] = resume_parser.extract_summary(resume_text)                # Summary section of resume
    #details['objective'] = resume_parser.extract_objective(resume_text)            # Objective section of resume
    #details['accomplishments'] = resume_parser.extract_accomplishments(resume_text) # Accomplishments section

    # Create a ResumeScorer instance
    scorer = resume_parser.ResumeScorer(details)

    # Calculate the score
    score = scorer.calculate_score()
    details['score'] = score

    return details


# Function to take a file as input and return parsed details
def extract_resume_details(pdf_file):
    resume_text = fetch_resume(pdf_file)
    return parse_resume(resume_text)

